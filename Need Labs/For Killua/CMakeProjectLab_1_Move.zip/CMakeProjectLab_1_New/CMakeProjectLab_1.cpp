﻿// CMakeProjectLab_1.cpp: определяет точку входа для приложения.
//

#include "CMakeProjectLab_1.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
